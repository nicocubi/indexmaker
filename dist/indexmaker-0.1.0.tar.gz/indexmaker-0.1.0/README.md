Generate a word index out of a pdf file -> the output is in Microsoft docx format. 
